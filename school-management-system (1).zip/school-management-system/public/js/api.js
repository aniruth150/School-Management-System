// public/js/api.js
// Small shared helper for talking to the backend API.

const API_BASE = "/api";

function getToken() {
  return localStorage.getItem("sms_token");
}

function getStoredUser() {
  const raw = localStorage.getItem("sms_user");
  return raw ? JSON.parse(raw) : null;
}

function saveSession(token, user) {
  localStorage.setItem("sms_token", token);
  localStorage.setItem("sms_user", JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem("sms_token");
  localStorage.removeItem("sms_user");
}

async function apiRequest(path, { method = "GET", body = null, auth = false } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth) {
    const token = getToken();
    if (token) headers["Authorization"] = "Bearer " + token;
  }

  const res = await fetch(API_BASE + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null,
  });

  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    data = null;
  }

  if (!res.ok) {
    const message = (data && data.message) || "Something went wrong. Please try again.";
    throw new Error(message);
  }

  return data;
}

// Redirects the user to the right dashboard based on their role.
function goToDashboard(role) {
  if (role === "admin") window.location.href = "admin-dashboard.html";
  else if (role === "teacher") window.location.href = "teacher-dashboard.html";
  else if (role === "student") window.location.href = "student-dashboard.html";
  else window.location.href = "index.html";
}

// Guards a dashboard page: redirects to login if not authenticated,
// or if logged in under the wrong role.
function requireAuth(expectedRole) {
  const token = getToken();
  const user = getStoredUser();
  if (!token || !user) {
    window.location.href = "index.html";
    return null;
  }
  if (expectedRole && user.role !== expectedRole) {
    goToDashboard(user.role);
    return null;
  }
  return user;
}

function logout() {
  clearSession();
  window.location.href = "index.html";
}
