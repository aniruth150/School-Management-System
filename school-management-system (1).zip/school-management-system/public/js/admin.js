// public/js/admin.js
const user = requireAuth("admin");

if (user) {
  document.getElementById("userBadge").textContent = `${user.name} (Admin)`;
  loadSummary();
  loadStudents();
  loadTeachers();
}

async function loadSummary() {
  try {
    const data = await apiRequest("/admin/summary", { auth: true });
    document.getElementById("studentCount").textContent = data.totalStudents;
    document.getElementById("teacherCount").textContent = data.totalTeachers;
  } catch (err) {
    console.error(err);
  }
}

async function loadStudents() {
  const area = document.getElementById("studentsArea");
  try {
    const students = await apiRequest("/admin/students", { auth: true });

    if (students.length === 0) {
      area.innerHTML = `<div class="empty-state">No students have registered yet.</div>`;
      return;
    }

    area.innerHTML = renderTable(students, "student");
  } catch (err) {
    area.innerHTML = `<div class="alert error">${err.message}</div>`;
  }
}

async function loadTeachers() {
  const area = document.getElementById("teachersArea");
  try {
    const teachers = await apiRequest("/admin/teachers", { auth: true });

    if (teachers.length === 0) {
      area.innerHTML = `<div class="empty-state">No teachers have registered yet.</div>`;
      return;
    }

    area.innerHTML = renderTable(teachers, "teacher");
  } catch (err) {
    area.innerHTML = `<div class="alert error">${err.message}</div>`;
  }
}

function renderTable(rows, role) {
  const extraHeader =
    role === "student"
      ? `<th>Class</th><th>Roll No.</th>`
      : `<th>Subject</th><th>Qualification</th>`;

  const rowsHtml = rows
    .map((r) => {
      const extraCells =
        role === "student"
          ? `<td>${escapeHtml(r.class_name || "-")}</td><td>${escapeHtml(r.roll_number || "-")}</td>`
          : `<td>${escapeHtml(r.subject || "-")}</td><td>${escapeHtml(r.qualification || "-")}</td>`;

      return `
        <tr>
          <td>${escapeHtml(r.name)}</td>
          <td>${escapeHtml(r.email)}</td>
          <td>${escapeHtml(r.phone || "-")}</td>
          ${extraCells}
          <td><span class="badge ${role}">${role}</span></td>
          <td><button class="btn danger small" onclick="deleteUser(${r.id}, '${role}')">Remove</button></td>
        </tr>`;
    })
    .join("");

  return `
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          ${extraHeader}
          <th>Role</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>${rowsHtml}</tbody>
    </table>`;
}

async function deleteUser(id, role) {
  if (!confirm("Remove this user? This cannot be undone.")) return;
  try {
    await apiRequest(`/admin/${role}/${id}`, { method: "DELETE", auth: true });
    loadSummary();
    loadStudents();
    loadTeachers();
  } catch (err) {
    alert(err.message);
  }
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
