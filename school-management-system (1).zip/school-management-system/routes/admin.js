// routes/admin.js
const express = require("express");
const { pool } = require("../database");
const { verifyToken, requireRole } = require("../middleware/auth");

const router = express.Router();

// All routes below require a valid token AND admin role
router.use(verifyToken, requireRole("admin"));

const STUDENT_COLUMNS = `id, name, email, phone, class_name, roll_number, created_at`;
const TEACHER_COLUMNS = `id, name, email, phone, subject, qualification, created_at`;

// ---------------- GET all students ----------------
router.get("/students", async (req, res) => {
  try {
    const [students] = await pool.query(
      `SELECT ${STUDENT_COLUMNS} FROM students ORDER BY created_at DESC`
    );
    res.json(students);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Could not load students." });
  }
});

// ---------------- GET all teachers ----------------
router.get("/teachers", async (req, res) => {
  try {
    const [teachers] = await pool.query(
      `SELECT ${TEACHER_COLUMNS} FROM teachers ORDER BY created_at DESC`
    );
    res.json(teachers);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Could not load teachers." });
  }
});

// ---------------- GET dashboard summary counts ----------------
router.get("/summary", async (req, res) => {
  try {
    const [[{ c: totalStudents }]] = await pool.query("SELECT COUNT(*) AS c FROM students");
    const [[{ c: totalTeachers }]] = await pool.query("SELECT COUNT(*) AS c FROM teachers");
    res.json({ totalStudents, totalTeachers });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Could not load summary." });
  }
});

// ---------------- DELETE a student ----------------
router.delete("/student/:id", async (req, res) => {
  try {
    const [result] = await pool.query("DELETE FROM students WHERE id = ?", [req.params.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Student not found." });
    }
    res.json({ message: "Student deleted successfully." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Could not delete student." });
  }
});

// ---------------- DELETE a teacher ----------------
router.delete("/teacher/:id", async (req, res) => {
  try {
    const [result] = await pool.query("DELETE FROM teachers WHERE id = ?", [req.params.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Teacher not found." });
    }
    res.json({ message: "Teacher deleted successfully." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Could not delete teacher." });
  }
});

module.exports = router;
