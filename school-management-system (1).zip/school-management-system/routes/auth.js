// routes/auth.js
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { pool } = require("../database");
const { verifyToken, JWT_SECRET } = require("../middleware/auth");

const router = express.Router();

// Maps a role to its table name
const TABLE = {
  admin: "admins",
  teacher: "teachers",
  student: "students",
};

// Checks whether an email already exists in ANY of the three tables
// (emails must be unique across the whole system).
async function emailExistsAnywhere(email) {
  const [admins] = await pool.query("SELECT id FROM admins WHERE email = ?", [email]);
  if (admins.length > 0) return true;

  const [teachers] = await pool.query("SELECT id FROM teachers WHERE email = ?", [email]);
  if (teachers.length > 0) return true;

  const [students] = await pool.query("SELECT id FROM students WHERE email = ?", [email]);
  if (students.length > 0) return true;

  return false;
}

// ---------------- REGISTER (students & teachers) ----------------
router.post("/register", async (req, res) => {
  const {
    name,
    email,
    password,
    role,
    phone,
    class_name,
    roll_number,
    subject,
    qualification,
  } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ message: "Name, email, password and role are required." });
  }

  if (!["student", "teacher"].includes(role)) {
    return res.status(400).json({ message: "Role must be either 'student' or 'teacher'." });
  }

  try {
    const exists = await emailExistsAnywhere(email);
    if (exists) {
      return res.status(409).json({ message: "An account with this email already exists." });
    }

    const password_hash = bcrypt.hashSync(password, 10);
    let result;

    if (role === "student") {
      [result] = await pool.query(
        `INSERT INTO students (name, email, password_hash, phone, class_name, roll_number)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [name, email, password_hash, phone || null, class_name || null, roll_number || null]
      );
    } else {
      [result] = await pool.query(
        `INSERT INTO teachers (name, email, password_hash, phone, subject, qualification)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [name, email, password_hash, phone || null, subject || null, qualification || null]
      );
    }

    return res.status(201).json({
      message: "Registration successful. You can now log in.",
      userId: result.insertId,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Something went wrong while registering." });
  }
});

// ---------------- LOGIN (admin, teacher, student) ----------------
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required." });
  }

  try {
    // Check each table in turn to find which role this email belongs to
    let user = null;
    let role = null;

    const [admins] = await pool.query("SELECT * FROM admins WHERE email = ?", [email]);
    if (admins.length > 0) {
      user = admins[0];
      role = "admin";
    }

    if (!user) {
      const [teachers] = await pool.query("SELECT * FROM teachers WHERE email = ?", [email]);
      if (teachers.length > 0) {
        user = teachers[0];
        role = "teacher";
      }
    }

    if (!user) {
      const [students] = await pool.query("SELECT * FROM students WHERE email = ?", [email]);
      if (students.length > 0) {
        user = students[0];
        role = "student";
      }
    }

    if (!user) {
      return res.status(401).json({ message: "Invalid email or password." });
    }

    const valid = bcrypt.compareSync(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ message: "Invalid email or password." });
    }

    const token = jwt.sign(
      { id: user.id, name: user.name, email: user.email, role },
      JWT_SECRET,
      { expiresIn: "8h" }
    );

    return res.json({
      message: "Login successful.",
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Something went wrong while logging in." });
  }
});

// ---------------- CURRENT LOGGED-IN USER ----------------
router.get("/me", verifyToken, async (req, res) => {
  const table = TABLE[req.user.role];
  if (!table) return res.status(400).json({ message: "Unknown role." });

  try {
    const [rows] = await pool.query(
      `SELECT * FROM ${table} WHERE id = ?`,
      [req.user.id]
    );

    if (rows.length === 0) return res.status(404).json({ message: "User not found." });

    const { password_hash, ...safeUser } = rows[0];
    res.json({ ...safeUser, role: req.user.role });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Something went wrong while fetching your profile." });
  }
});

module.exports = router;
